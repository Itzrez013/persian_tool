# persian_tool

A Python library for converting Persian words and numbers to English.

> 🚧 **This project is currently under development.**

## Features

Currently, `persian_tool` provides:

* Convert Persian digits to English digits
* Keep spaces and other characters unchanged
* Simple and lightweight API

More features will be added in future versions.

## Installation

You can install the package using pip:

```bash
pip install persian_tool
```

## Usage

Import the function and pass a string containing Persian digits:

```python
from persian_tool import pnum_to_enum

result = pnum_to_enum("۰۱۲۳۴۵۶۷۸۹")

print(result)
```

Output:

```text
0123456789
```

### Example with spaces

The function also keeps spaces and other characters unchanged:

```python
from persian_tool import pnum_to_enum

text = "شماره: ۰۹۱۲ ۱۲۳ ۴۵۶۷"

result = pnum_to_enum(text)

print(result)
```

Output:

```text
شماره: 0912 123 4567
```

### Example with mixed text

```python
from persian_tool import pnum_to_enum

text = "Price: ۱۲۵۰۰ تومان"

print(pnum_to_enum(text))
```

Output:

```text
Price: 12500
```
